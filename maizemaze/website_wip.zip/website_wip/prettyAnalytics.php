<!DOCTYPE html>

<!-- 

	This is where we can look at the questions answered and other fun stuff. Maybe make a chart of categories/levels or something.
	Showing that this is a possibility is probably a good idea or at least worth discussing.


	-Mike

-->

<html>

<head>
<title> Analytics </title>
<link type="text/css" rel="stylesheet" href="css/mainSS.css">
<link type="text/css" rel="stylesheet" href="css/subSS.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

</head>

<body>
<?php include("header.php"); ?>
<div id="content">
  <div id="cHeader">
	<h2> Oooooo a chart! </h2>
  </div>
		<form method="link" action="index.php">
			<input type="submit" value="Back to main menu"/>
		</form>
</div>
<?php include("footer.php"); ?>
</body>


</html>

