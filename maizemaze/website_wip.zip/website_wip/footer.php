<footer>
<?php

echo "<p>Last Modified: " . date ("F d Y H:i:s.", filemtime($_SERVER["SCRIPT_FILENAME"])) . "</p>";

?>

</footer>